#define  _CRT_SECURE_NO_WARNINGS 1
#include <graphics.h>
#include <windows.h>
#include<mmsyscom.h>
#include<conio.h>
#pragma comment(lib,"Winmm.lib")
using namespace std;
void music()
{
	mciSendString(_T("open music.mp3 alias A"), 0, 0, 0);//���������ļ�music.mp3ΪA
	mciSendString(_T("Play A repeat"), 0, 0, 0); //��ʼ��������A
}
int num = -1;
IMAGE bgp;
int piece[15][15];

void putbackgroud()
{
	putimage(0, 0, 330, 330, &bgp, 60, 60);
	putimage(0, 0, 330, 330, &bgp, 60, 60);
	putimage(0, 330, 330, 330, &bgp, 60, 60);
	putimage(0, 330, 330, 330, &bgp, 60, 60);
}

void draw_line() {
	setlinecolor(BLACK);
	for (int x = 15; x < 300; x += 30) {
		line(x, 15, x, 285);

	}
	for (int y = 15; y < 300; y += 30) {
		line(15, y, 285, y);
	}
}
void initpiece()//��ʼ������
{
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 10; j++) {
			piece[i][j] = 0;
		}
	}
}

int change_piece(int x, int y)
{
	if (piece[x][y] != 0)
		return 0;
	else
		piece[x][y] = num;
	return -1;


}
void draw_piece(int m, int n)
{

	if (num == -1)
		setfillcolor(WHITE);

	else if (num == 1)
		setfillcolor(BLACK);

	int x, y;
	x = m / 30;
	y = n / 30;
	if (change_piece(x, y) == 0)
		return;


	fillcircle(m - (m % 30) + 15, n - (n % 30) + 15, 13);

	num *= -1;


}

//�жϲ��������������
int check_five_piece(int x, int y)
{
	if (x > 12 || y > 12 || x < 0 || y < 0)
		return 0;
	if (piece[x][y] == piece[x - 1][y] && piece[x][y] == piece[x - 2][y]
		&& piece[x][y] == piece[x + 1][y] && piece[x][y] == piece[x + 2][y])
		return 1;
	if (piece[x][y] == piece[x][y - 1] && piece[x][y] == piece[x][y - 2]
		&& piece[x][y] == piece[x][y + 1] && piece[x][y] == piece[x][y + 2])
		return 1;
	if (piece[x][y] == piece[x - 1][y - 1] && piece[x][y] == piece[x - 2][y - 2]
		&& piece[x][y] == piece[x + 1][y + 1] && piece[x][y] == piece[x + 2][y + 2])
		return 1;
	if (piece[x][y] == piece[x - 1][y + 1] && piece[x][y] == piece[x - 2][y + 2]
		&& piece[x][y] == piece[x + 1][y - 1] && piece[x][y] == piece[x + 2][y - 2])
		return 1;

	return 0;

}

int check_over()
{

	for (int i = 0; i < 15; i++)
		for (int j = 0; j < 10; j++) {
			if (piece[i][j] == 0)
				continue;
			if (check_five_piece(i, j) == 1)
				return 1;


		}
	return 0;

}
int main() {
	initgraph(310, 310);
	setbkcolor(YELLOW);
	loadimage(&bgp, _T("background.jpg"));
	settextcolor(RED);
	settextstyle(42, 20, _T("����"));
	setbkmode(TRANSPARENT);

	cleardevice(); // ��ջ���

	putimage(0, 0, 480, 480, &bgp, 10, 10);
	putbackgroud;
	draw_line();
	MOUSEMSG m;
	music();
	int sum = 1;
	while (1) {
		m = GetMouseMsg();
		if (m.uMsg == WM_LBUTTONDOWN) ///�����������
		{
			draw_piece(m.x, m.y);

		}
		if (m.uMsg == WM_RBUTTONDOWN)//�Ҽ��ر�����
		{
			sum++;
			int a = sum % 2;
			if (a == 0)
				mciSendString(_T("Pause A"), 0, 0, 0);//��ͣ��������A
			if (a == 1)
				mciSendString(_T("Resume  A"), 0, 0, 0);//������������
		}
		if (check_over() == 1)
		{
			outtextxy(70, 135, _T("��Ϸ����"));
			system("pause");
			return 0;
		}
	}
	return 0;
}